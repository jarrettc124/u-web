var App = angular.module('sampleApp', ['ngRoute', 'appRoutes', 'LogoCtrl','LoginCtrl', 'InstagramCtrl', 'SignupCtrl', 'MainCtrl', 'NerdCtrl', 'GeekCtrl', 'FirstPageCtrl']);

