module.exports = {
	url : 'mongodb://<user>:<pass>@mongo.onmodulus.net:27017/uw45mypu'
}